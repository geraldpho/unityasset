﻿using UnityEditor;
using UnityEngine;
using System.Collections;
using Cainos.LucidEditor;


namespace Cainos.PixelArtPlatformer_VillageProps
{
    [CustomEditor(typeof(Elevator))]
    public class ElevatorEditor : LucidEditor.LucidEditor
    {
    }
}
